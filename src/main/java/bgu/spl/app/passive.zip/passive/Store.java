package bgu.spl.app.passive;

import java.util.concurrent.ConcurrentLinkedQueue;

public class Store {
	
	private ConcurrentLinkedQueue <ShoeStorageInfo> _Inventory = new ConcurrentLinkedQueue <ShoeStorageInfo>();
	private ConcurrentLinkedQueue <Receipt> _Receipts = new ConcurrentLinkedQueue <Receipt>();

	private static class StoreHolder {
        private static Store instance = new Store();
    }
	
    private Store() { }

    public static Store getInstance() {
        return StoreHolder.instance;
    }
    
    public void load(ShoeStorageInfo [] storage) {
    	for (int i = 0; i < storage.length; i++) {
			this._Inventory.add(storage[i]);
		}
    }
    
    public BuyResult take(String shoeType, boolean onlyDiscount) {
    	Object [] temp = this._Inventory.toArray();
    	int index = findShoe(shoeType);
    	BuyResult r;
    	if (index == -1) {
    		r = BuyResult.NOT_IN_STOCK;
			return r;
		}
    	ShoeStorageInfo t = (ShoeStorageInfo) temp[index];
    	synchronized(t) {
    		if(t.getAmountOnStorage() == 0) {
    			r = BuyResult.NOT_IN_STOCK;
    			return r;
    		}
    		if(onlyDiscount) {
    			if (t.getDiscountedAmount() > 0) {
					r = BuyResult.DISCOUNTED_PRICE;
					t.decAmountOnStorage(1);
					t.decDiscountedAmount(1);
					return r;
				}
    			r = BuyResult.NOT_ON_DISCOUNT;
    			return r;
    		}
    		if (t.getDiscountedAmount() > 0) {
				r = BuyResult.DISCOUNTED_PRICE;
				t.decAmountOnStorage(1);
				t.decDiscountedAmount(1);
				return r;
    		}
			r = BuyResult.REGULAR_PRICE;
			t.decAmountOnStorage(1);
			return r;
		}
    }
    
    public void add(String shoeType, int amount) {
    	int index = findShoe(shoeType);
    	if (index != -1) {
    		Object [] temp = this._Inventory.toArray();
        	((ShoeStorageInfo) temp[index]).incAmountOnStorage(amount);
		}
    	else {
    		this._Inventory.add(new ShoeStorageInfo(shoeType, amount, 0));
    	}
    }
    
    public void addDiscount(String shoeType, int amount) {
    	int index = findShoe(shoeType);
    	if (index != -1) {
    		Object [] temp = this._Inventory.toArray();
        	((ShoeStorageInfo) temp[index]).incDiscountedAmount(amount);
		}
    }
    
    public void file(Receipt receipt) {
    	this._Receipts.add(receipt);
    }
    
    public void print() {
    	System.out.println("Inventory:");
    	while(this._Inventory.size() > 0) {
    		ShoeStorageInfo temp = this._Inventory.poll();
			System.out.println("	Shoe type: " + temp.getShoeType() + ", Amount on storage: " + temp.getAmountOnStorage() + ", Discounted amount on storage: " + temp.getDiscountedAmount());
			System.out.println();
    	}
    	System.out.println();
    	System.out.println("Receipts:");
    	int i = 1;
    	while(this._Receipts.size() > 0) {
    		System.out.println("	Receipt " + i + ":");
    		Receipt temp = this._Receipts.poll();
    		System.out.println("		Seller: " + temp.getSeller());
    		System.out.println("		Customer: " + temp.getCustomer());
    		System.out.println("		Shoe type: " + temp.getShoeType());
    		System.out.println("		Bought on discount: " + temp.isDiscount());
    		System.out.println("		Issued tick: " + temp.getIssuedTick());
    		System.out.println("		Request tick: " + temp.getRequestTick());
    		System.out.println("		Amount sold: " + temp.getAmountSold());
    		System.out.println();
    	}
    }
    
    private int findShoe(String shoeType) {
    	Object [] temp = this._Inventory.toArray();
    	for (int i = 0; i < temp.length; i++) {
			if (((ShoeStorageInfo) temp[i]).getShoeType().equals(shoeType)) {
				return i;
			}
		}
    	return -1;
    }
}
