package bgu.spl.app.active;

import java.util.List;
import java.util.logging.*;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

import bgu.spl.app.passive.NewDiscountBroadcast;
import bgu.spl.app.passive.PurchaseOrderRequest;
import bgu.spl.app.passive.PurchaseSchedule;
import bgu.spl.app.passive.TickBroadcast;
import bgu.spl.mics.MicroService;

public class WebsiteClientService extends MicroService {
	
	private int currTick = 0;
	private List <PurchaseSchedule> purchaseSchedule;
	private Set <String> wishList;
	private final static Logger l = Logger.getLogger("WebsiteClientService");
	
	public WebsiteClientService(String name, List <PurchaseSchedule> l, Set <String> wl, CountDownLatch c) {
		super(name, c);
		purchaseSchedule = l;
		wishList = wl;
	}
	
	private void setTick(int t) {
		this.currTick = t;
	}

	@Override
	protected void initialize() {
		
		l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " began initialization.");
		this.subscribeBroadcast(TickBroadcast.class, tb -> {
			setTick(tb.getTick());
			l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " received tick #" + this.currTick);
			if (this.currTick == tb.getDuration()) {
				l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will now terminate. Time is up!!");
				this.terminate();
			}
			for (int i = 0; i < purchaseSchedule.size(); i++) {
				if (currTick == purchaseSchedule.get(i).getTick()) {
					l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " found item " + purchaseSchedule.get(i).getShoe() + " in purchase schedule.");
					if (this.sendRequest(new PurchaseOrderRequest(purchaseSchedule.get(i).getShoe(), 1, false, this.getName(), currTick), onComplete -> {
						for (int j = 0; j < this.purchaseSchedule.size(); j++) {
							if (this.purchaseSchedule.get(j).getShoe().equals(onComplete.getShoeType()) && this.purchaseSchedule.get(j).getTick() == onComplete.getIssuedTick()) {
								l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will now remove item " + purchaseSchedule.get(j).getShoe() + " from purchase schedule after completing purchase.");
								this.purchaseSchedule.remove(j);
								if (this.purchaseSchedule.size() == 0 && this.wishList.isEmpty()) {
									l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will terminate since completed purchase schedule and wishlist.");
									this.terminate();
								}
							}
						}
					}));
					else {
						l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will now now remove item " + purchaseSchedule.get(i).getShoe() + " from purchase schedule because sent request returned false.");
						this.purchaseSchedule.remove(i);
						if (this.purchaseSchedule.size() == 0 && this.wishList.isEmpty()) {
							l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will terminate since completed purchase schedule and wishlist.");
							this.terminate();
						}
					}
				}
			}
		});
		
		this.subscribeBroadcast(NewDiscountBroadcast.class, ndb -> {
			l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " received a new discount broadcast: " + ndb.getShoeType());
			if (this.wishList.contains(ndb.getShoeType())) {
				l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " found item " + ndb.getShoeType() + " on wishlist.");
				if (this.sendRequest(new PurchaseOrderRequest(ndb.getShoeType(), 1, true, this.getName(), this.currTick), onComplete -> {
					if(onComplete != null) {
						l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will remove " + ndb.getShoeType() + " from wishlist.");
						this.wishList.remove(ndb.getShoeType());
						if (this.purchaseSchedule.size() == 0 && this.wishList.isEmpty()) {
							l.getLogger("WebsiteClientService").log(Level.INFO, this.getName() + " will terminate since completed purchase schedule and wishlist.");
							this.terminate();
						}
					}
				}));
			}
		});
		
		l.getLogger("WebsiteClientServer").log(Level.INFO, this.getName() + "- countdown.");
		this._CDL.countDown();
	}
}
