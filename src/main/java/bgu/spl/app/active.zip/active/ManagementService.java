package bgu.spl.app.active;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

import bgu.spl.app.passive.DiscountSchedule;
import bgu.spl.app.passive.ManufacturingOrderRequest;
import bgu.spl.app.passive.NewDiscountBroadcast;
import bgu.spl.app.passive.Receipt;
import bgu.spl.app.passive.RestockRequest;
import bgu.spl.app.passive.Store;
import bgu.spl.app.passive.TickBroadcast;
import bgu.spl.mics.MicroService;

public class ManagementService extends MicroService {
	
	private int currTick = 0;
	private List <DiscountSchedule> _discountSchedule;
	private HashMap <String, Integer> Orders = new HashMap <String, Integer>();
	private final static Logger l = Logger.getLogger("ManagementService");


	public ManagementService(String name, List<DiscountSchedule> dS, CountDownLatch c) {
		super(name, c);
		this._discountSchedule = dS;
		// TODO Auto-generated constructor stub
	}
	
	private void setTick(int t) {
		this.currTick = t;
	}

	@Override
	protected void initialize() {
		
		l.getLogger("ManagementService").log(Level.INFO, this.getName() + " began initialization.");
		this.subscribeBroadcast(TickBroadcast.class, tb -> {
			setTick(tb.getTick());
			l.getLogger("ManagementService").log(Level.INFO, this.getName() + " received tick #" + this.currTick);
			if (this.currTick == tb.getDuration()) {
				l.getLogger("ManagementService").log(Level.INFO, this.getName() + " will now terminate. Time is up!!");
				this.terminate();
			}
			
			for (int i = 0; i < _discountSchedule.size(); i++) {
				if (this._discountSchedule.get(i).getTick() == this.currTick) {
					Store.getInstance().addDiscount(this._discountSchedule.get(i).getShoeType(), this._discountSchedule.get(i).getAmount());
					l.getLogger("ManagementService").log(Level.INFO, this.getName() + " will send a NewDiscountBroadcast for " + this._discountSchedule.get(i).getAmount() + " " + this._discountSchedule.get(i).getShoeType());
					this.sendBroadcast(new NewDiscountBroadcast(this._discountSchedule.get(i).getShoeType(), this._discountSchedule.get(i).getAmount()));
				}
			}
		});
		
		this.subscribeRequest(RestockRequest.class,RR -> {
			l.getLogger("ManagementService").log(Level.INFO, this.getName() + " received a RestockRequest for " + RR.getShoeType());
			if (Orders.containsKey(RR.getShoeType())) {
				l.getLogger("ManagementService").log(Level.INFO, this.getName() + " saw that previous order for " + RR.getShoeType() + " exists.");
				int x = Orders.get(RR.getShoeType());
				if (x != 0) {
					Orders.replace(RR.getShoeType(), x-1);
					l.getLogger("ManagementService").log(Level.INFO, this.getName() + " reserved shoe " + RR.getShoeType());
				}
				else {
					l.getLogger("ManagementService").log(Level.INFO, this.getName() + " placed a new order for " + currTick%5 +1 + RR.getShoeType());
					if (this.sendRequest(new ManufacturingOrderRequest(RR.getShoeType(), currTick%5 +1, currTick), MOR -> {
						Store.getInstance().add(MOR.getShoeType(), Orders.get(MOR.getShoeType()));
						Store.getInstance().file(MOR);
						l.getLogger("ManagementService").log(Level.INFO, this.getName() + " added stock from shipment to inventory");
						this.complete(RR, true);
					}));
					else {
						l.getLogger("ManagementService").log(Level.INFO, this.getName() + " responded that no factories are available. Cannot restock.");
						this.complete(RR, false);
					}
				}	
			}
			else {
				l.getLogger("ManagementService").log(Level.INFO, this.getName() + " placed a new order for " + currTick%5 +1 + RR.getShoeType());
				Orders.put(RR.getShoeType(), currTick%5);
				if (this.sendRequest(new ManufacturingOrderRequest(RR.getShoeType(), currTick%5 +1, currTick), MOR -> {
					Store.getInstance().add(MOR.getShoeType(), Orders.get(MOR.getShoeType()));
					Store.getInstance().file(MOR);
					l.getLogger("ManagementService").log(Level.INFO, this.getName() + " added stock from shipment to inventory");
					this.complete(RR, true);
				}));
				else {
					l.getLogger("ManagementService").log(Level.INFO, this.getName() + " responded that no factories are available. Cannot restock.");
					this.complete(RR, false);
				}
			}
		});
		l.getLogger("ManagementService").log(Level.INFO, this.getName() + "- countdown.");
		this._CDL.countDown();
	}
}
