/**
 * 
 */
package bgu.spl.app.active;

import java.util.concurrent.CountDownLatch;

import bgu.spl.app.passive.BuyResult;
import bgu.spl.app.passive.PurchaseOrderRequest;
import bgu.spl.app.passive.Receipt;
import bgu.spl.app.passive.RestockRequest;
import bgu.spl.app.passive.Store;
import bgu.spl.app.passive.TickBroadcast;
import bgu.spl.mics.MicroService;
import java.util.logging.*;
/**
 * @author gilliam
 *
 */
public class SellingService extends MicroService {
	
	private final static Logger l = Logger.getLogger("SellingService");
	private int currTick = 0;
	/**
	 * @param name
	 */
	public SellingService(String name, CountDownLatch c) {
		super(name, c);
	}

	@Override
	protected void initialize() {
        l.getLogger("SellingService").log(Level.INFO, this.getName() + " began initialization.");

		this.subscribeBroadcast(TickBroadcast.class, tb -> {
			setTick(tb.getTick());
			l.getLogger("SellingService").log(Level.INFO, this.getName() + " received tick #" + this.currTick);
			if (this.currTick == tb.getDuration()) {
				l.getLogger("SellingService").log(Level.INFO, this.getName() + " will now terminate. Time is up!!");
				this.terminate();
			}
		});
        
		this.subscribeRequest(PurchaseOrderRequest.class, por -> {
			
			String customerName = por.getName();
			String shoeType = por.getShoeType();
			int issuedTick = por.getTick();
			boolean onlyDiscount = por.getOnlyDiscount();
			l.getLogger("SellingService").log(Level.INFO, this.getName() + " received a PurchaseOrderRequest from " + customerName + " for " + shoeType);
			BuyResult r;
			r = Store.getInstance().take(shoeType, onlyDiscount);
			if (r == BuyResult.NOT_ON_DISCOUNT) {
				l.getLogger("SellingService").log(Level.INFO, this.getName() + " responded to " + customerName + " that " + shoeType + " is NOT_ON_DISCOUNT.");
				this.complete(por, null);
			}
			else if (r == BuyResult.REGULAR_PRICE) {
				Receipt receipt = new Receipt(this.getName(), customerName, shoeType, false, currTick, issuedTick, 1);
				Store.getInstance().file(receipt);
				l.getLogger("SellingService").log(Level.INFO, this.getName() + " sold " + shoeType + " to " + customerName + " for REGULAR_PRICE.");
				this.complete(por, receipt);
			}
			else if (r == BuyResult.DISCOUNTED_PRICE) {
				Receipt receipt = new Receipt(this.getName(), customerName, shoeType, true, currTick, issuedTick, 1);
				Store.getInstance().file(receipt);
				l.getLogger("SellingService").log(Level.INFO, this.getName() + " sold " + shoeType + " to " + customerName + " for DISCOUNTED_PRICE.");
				this.complete(por, receipt);
			}
			else {
				if (this.sendRequest(new RestockRequest(shoeType), oc -> {
					Receipt receipt = new Receipt(this.getName(), customerName, shoeType, false, currTick, issuedTick, 1);
					Store.getInstance().file(receipt);
					l.getLogger("SellingService").log(Level.INFO, this.getName() + " told " + customerName + " that " + shoeType + "is NOT_IN_STOCK. RestockRequest returned true.");
					this.complete(por, receipt);
				}));
				else {
					l.getLogger("SellingService").log(Level.INFO, this.getName() + " told " + customerName + " that " + shoeType + "is NOT_IN_STOCK. Nobody can manufacture the RestockRequest.");
					this.complete(por, null);
				}	
			}
		});
		l.getLogger("SellingService").log(Level.INFO, this.getName() +"- countdown.");
		this._CDL.countDown();
	}
	
	private void setTick(int t) {
		this.currTick = t;
	}

}
