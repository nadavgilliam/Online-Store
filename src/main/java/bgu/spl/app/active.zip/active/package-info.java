/**
 * 
 */
/**
 * @author gilliam
 *
 */
package bgu.spl.app.active;